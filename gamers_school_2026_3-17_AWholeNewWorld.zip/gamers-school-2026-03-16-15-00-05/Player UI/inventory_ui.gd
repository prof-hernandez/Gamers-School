extends Control

@onready var inv: Inv = preload("res://Player/Player Inventory.tres")
@onready var slot: Array = $NinePatchRect/GridContainer.get_children()

var is_open

func _ready():
	Global.collect_item.connect(_on_collect_item)
	is_open = true
	update_slots()
	open()

#func _process(delta):
	#if Input.is_action_just_pressed("interact"):
		#print("inv")
		#if is_open:
			#close()
		#else:
			#open()

func update_slots():
	for i in range(min(inv.items.size(),slot.size())):
		slot[i].update(inv.items[i])

func open():
	visible = true
	is_open = true
	Global.inventory_open = true

func close():
	visible = false
	is_open = false
	Global.inventory_open = false

func _on_collect_item(item : Items, num : int):
	pass

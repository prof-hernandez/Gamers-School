extends CharacterBody2D



@export var speed: int 
@export var vector: Vector2
@export var friendly: bool
@export var damage_points: float



func _physics_process(delta: float) -> void:
	velocity = speed * vector.normalized()
	move_and_slide()
	
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		var collided = collision.get_collider()
		
		if collided.get_parent().name == "Enemies":
			if friendly:
				Global.enemy_take_damage.emit(damage_points)
				self.queue_free()
		elif collided.name == "Character":
			if !friendly:
				Global.player_take_damage.emit(damage_points)
				self.queue_free()

extends Control

@export var coin_count : int
@export var experience_count : int
@onready var coin_label = $"Coin/Coin Label"
@onready var exp_label = $"Experience/Exp Label"

func _ready() -> void:
	coin_count = 0
	experience_count = 0
	_update_coin_label()
	Global.update_counters.connect(_update_counters)


func _update_counters(coins : int, experience : int):
	coin_count += coins
	experience_count += experience
	_update_coin_label()
	_update_exp_label()

func _update_coin_label():
	coin_label.text = "Coins: " + str(coin_count)

func _update_exp_label():
	exp_label.text = "Exp: " + str(experience_count)

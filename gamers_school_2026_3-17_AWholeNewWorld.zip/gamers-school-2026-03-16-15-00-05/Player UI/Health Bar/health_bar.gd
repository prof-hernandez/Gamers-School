extends TextureProgressBar




func take_damage(damage : float):
	value -= damage
	if value <= 0:
		Global.end_game.emit()

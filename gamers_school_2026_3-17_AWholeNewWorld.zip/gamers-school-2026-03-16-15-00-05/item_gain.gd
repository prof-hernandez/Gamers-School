extends Node2D


var speed = 3

func _ready() -> void:
	await get_tree().create_timer(1.0).timeout
	self.queue_free()

func _physics_process(delta: float) -> void:
	self.position -= Vector2(0,speed)
	speed -= .1
	

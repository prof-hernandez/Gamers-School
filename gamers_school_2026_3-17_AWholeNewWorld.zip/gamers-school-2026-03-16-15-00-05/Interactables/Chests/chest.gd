extends Area2D

@onready var animation = $chest_animation
@onready var open = false
@export var item : Items
@export var coins : int 
@export var experience : int
@onready var collected = false

const ITEM_GAIN = preload("res://Interactables/Chests/item_gain.tscn")
const COIN_GAIN_PNG = preload("res://Item System/Items/Coin.png")
const EXP_GAIN_PNG = preload("res://Interactables/Experience.png")

func _physics_process(delta: float) -> void:
	var bodies = get_overlapping_bodies()
	var found = false
	if !collected:
		for body in bodies:
			
			if body.name == "Character":
				if !open:
					print("interact")
					_open()
				found = true
				break
		
		if !found && open:
			_close()

func _process(delta: float) -> void:
	if(open && Input.is_action_just_pressed("interact")):
		_give_items()

func _close():
	Global.chest_close.emit()
	animation.frame = 0
	open = false

func _open():
	Global.chest_open.emit(self)
	animation.frame = 1
	open = true

func _give_items():
	Global.update_counters.emit(coins,experience)
	collected = true
	animation.frame = 1
	for i in range(0, coins):
		var coin_gain = ITEM_GAIN.instantiate()
		coin_gain.texture = COIN_GAIN_PNG
		add_child(coin_gain)
		
		print("coin")
		await get_tree().create_timer(.25).timeout
		
	for i in range(0, experience):
		var exp_gain = ITEM_GAIN.instantiate()
		exp_gain.texture = EXP_GAIN_PNG
		add_child(exp_gain)
		
		print("exp")
		await get_tree().create_timer(.25).timeout
		
	coins = 0
	experience = 0
	

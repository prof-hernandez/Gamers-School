extends Panel

@onready var item_visual: Sprite2D = $item_display

func update(item: Items):
	if !item:
		item_visual.hide()
	else:
		item_visual.texture = item.texture
		item_visual.show()

extends Node2D

const PROJECTILE_PATH = preload("res://Entities/projectile.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Global.shoot.connect(_on_shoot)


func _on_shoot(damage : float, good_guy : bool, direction : Vector2, parent_position : Vector2):
	var projectile = PROJECTILE_PATH.instantiate()
	projectile.global_position = parent_position
	projectile.damage_points = damage
	projectile.friendly = good_guy
	projectile.vector = direction
	projectile.speed = 300
	add_child(projectile)
	

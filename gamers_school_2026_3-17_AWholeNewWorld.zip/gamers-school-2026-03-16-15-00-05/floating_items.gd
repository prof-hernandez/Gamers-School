extends Node2D

const ITEM_PATH = preload("res://Item System/item.tscn")

func _ready() -> void:
	Global.drop_item.connect(_on_drop_item)

func _on_drop_item(item : Items, drop_point : Vector2):
	var floating_item = ITEM_PATH.instantiate()
	floating_item.item_texture.texture = item.texture
	floating_item.global_position = drop_point
	add_child(floating_item)
	

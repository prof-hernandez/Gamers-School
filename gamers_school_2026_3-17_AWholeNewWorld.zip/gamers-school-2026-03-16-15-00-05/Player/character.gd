extends CharacterBody2D


class_name Character

@export var speed = 300.0
@export var character_inventory: Inv
@onready var _character_animation = $character_animation
@onready var _recent_direction = Vector2(1,0)

func _ready() -> void:
	Global.player_take_damage.connect(_on_player_take_damage)

func get_input():
	var input_direction = Input.get_vector("left","right","up","down")
	velocity = input_direction * speed
	if input_direction != Vector2(0,0):
		_recent_direction = input_direction

func _physics_process(delta):
	get_input()
	move_and_slide()
	
	#for i in get_slide_collision_count():
		#var collision = get_slide_collision(i)
		#var collided = collision.get_collider()
		#
		#if collided.get_parent().name == "Interactables":
			#print("open")
			#collided.interact()
		#elif collided.name == "Character":
			#pass

func _process(_delta):
	if Input.is_action_pressed("right"):
		_character_animation.scale.x = 1
		_character_animation.play("default")
		
	elif Input.is_action_pressed("left"):
		_character_animation.scale.x = -1
		_character_animation.play("default")
		
	elif Input.is_action_pressed("up"):
		_character_animation.play("default")
		
	elif Input.is_action_pressed("up"):
		_character_animation.play("default")
	else:
		_character_animation.stop()
	
	Global.where_is_player.emit(global_position)
	if Input.is_action_just_pressed("click"):
		Global.shoot.emit(10, true, get_local_mouse_position(), global_position + get_local_mouse_position().normalized()*40)

func _on_player_take_damage(damage_points : float):
	$"Player UI/Health Bar".take_damage(damage_points)

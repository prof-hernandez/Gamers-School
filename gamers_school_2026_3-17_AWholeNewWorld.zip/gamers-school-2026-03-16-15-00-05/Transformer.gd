extends Tool

class_name Transformer

@export var transform: Vector2
@export var operator_shape: Shape2D 
@export var operator_image: Texture2D

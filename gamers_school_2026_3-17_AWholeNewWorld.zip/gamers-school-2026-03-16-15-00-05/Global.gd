extends Node



signal enemy_take_damage(damage : float)
signal shoot(damage : float, good_guy : bool, direction : Vector2, parent_position : Vector2)
signal where_is_player(location : Vector2)
signal end_game()
signal player_take_damage()
signal drop_item(item : Items)
signal chest_open(chest : Area2D)
signal chest_close()
signal collect_item(item : Items, number : int)
signal update_counters(coins : int, experience : int)

@onready var inventory_open = false


func _ready() -> void:
	end_game.connect(_on_end_game)
	

func _on_end_game():
	get_tree().paused = true
	

extends CharacterBody2D


var speed = 0
var vector: Vector2
@onready var _enemy_sprite = $enemy_sprite
@onready var _last_known_player_position : Vector2
@onready var health = get_node("Health Bar") 

func _ready() -> void:
	Global.where_is_player.connect(_on_where_is_player)
	Global.enemy_take_damage.connect(_on_enemy_take_damage)
	vector = Vector2(0.0,0.0)

func _physics_process(delta: float) -> void:
	
	move_and_slide()

func _on_where_is_player(location : Vector2):
	_last_known_player_position = location
	if global_position.distance_to(location) >= 50:
		if global_position.distance_to(location) <= 200:
			speed = 50
			vector = global_position.direction_to(location)
			if vector.x < 0:
				_enemy_sprite.scale.x = 1
			else:
				_enemy_sprite.scale.x = -1
		else:
			speed = 0
	velocity = speed * vector


func _on_shot_timer_timeout() -> void:
	print("fire")
	if global_position.distance_to(_last_known_player_position) < 200:
		Global.shoot.emit(10.0, false, vector, global_position)

func _on_enemy_take_damage(damage_points : float):
	health.take_damage(damage_points)

extends Resource

class_name Inv

@export var items: Array[Items]

#func _init(size : int):
	#items.resize(size)

extends Control


@onready var inv: Inv 
@onready var slot: Array = $NinePatchRect/GridContainer.get_children()

var is_open

func _ready():
	Global.chest_open.connect(_on_chest_open)
	Global.chest_close.connect(_on_chest_close)
	_on_chest_close()

func update_slots():
	for i in range(min(inv.items.size(),slot.size())):
		slot[i].update(inv.items[i])

func _on_chest_open(chest : Area2D):
	#inv = chest.inventory
	
	#update_slots()
	
	visible = true
	is_open = true

func _on_chest_close():
	visible = false
	is_open = false
